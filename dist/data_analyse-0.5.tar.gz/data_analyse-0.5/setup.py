from setuptools import setup, find_packages

setup(
    name='Data_Analyse',
    version='0.5',
    py_modules=["Data_Analyse"],
    install_requires=['matplotlib', 'numpy']
    )